package avaliacao02_questao02;

public class Avaliacao02_questao02 {

    public static void main(String[] args) {
        Janela app = new Janela();
        
    }
    
}
