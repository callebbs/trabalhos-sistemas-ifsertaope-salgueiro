package avaliacao01_questao02;


public class ClienteEspecial  extends ContaCorrente {
    double taxaSaque = 0.1;
    double saldo = 0;
}
