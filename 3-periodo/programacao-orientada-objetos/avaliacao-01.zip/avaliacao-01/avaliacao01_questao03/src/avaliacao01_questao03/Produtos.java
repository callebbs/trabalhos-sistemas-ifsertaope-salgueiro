package avaliacao01_questao03;

public class Produtos {
    String nome;
    double preco;
    
}
