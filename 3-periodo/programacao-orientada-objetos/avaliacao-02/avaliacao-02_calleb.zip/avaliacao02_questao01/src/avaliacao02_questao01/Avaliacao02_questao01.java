package avaliacao02_questao01;

public class Avaliacao02_questao01 {

    public static void main(String[] args) {
        Janela app = new Janela();
    }
    
}