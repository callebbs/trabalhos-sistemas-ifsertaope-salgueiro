package avaliacao01_questao01;


public class Radio {
    boolean ligado;
    double frequencia;

}
