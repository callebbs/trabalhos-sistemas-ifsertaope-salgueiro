package avaliacao01_questao03;


public class Cd extends Produtos{
    int faixas;
    
}
